let slideIndex = 0;
const slides = document.querySelector('.slides');
if (slides) {
  const totalSlides = slides.children.length;
  setInterval(() => {
    slideIndex = (slideIndex + 1) % totalSlides;
    slides.style.transform = `translateX(-${slideIndex * 100}%)`;
  }, 4000);
}
const faqItems = document.querySelectorAll('.faq-item');
faqItems.forEach(item => {
  const question = item.querySelector('.faq-question');
  question.addEventListener('click', () => {
    const answer = item.querySelector('.faq-answer');
    const toggle = item.querySelector('.faq-toggle');
    const open = answer.style.display === 'block';
    document.querySelectorAll('.faq-answer').forEach(a => a.style.display = 'none');
    document.querySelectorAll('.faq-toggle').forEach(t => t.textContent = '+');
    answer.style.display = open ? 'none' : 'block';
    toggle.textContent = open ? '+' : '–';
  });
});
const contactToggle = document.getElementById('contact-toggle') || document.getElementById('contactToggle');
const contactPopup = document.getElementById('contact-popup') || document.getElementById('contactList');
if (contactToggle && contactPopup) {
  contactToggle.addEventListener('click', () => {
    contactPopup.style.display = contactPopup.style.display === 'flex' ? 'none' : 'flex';
  });
}
const feedbackForm = document.getElementById('feedbackForm');
if (feedbackForm) {
  feedbackForm.addEventListener('submit', e => {
    e.preventDefault();
    alert('Thank you for your feedback!');
    feedbackForm.reset();
  });
}
const dropdowns = document.querySelectorAll('.dropdown');
dropdowns.forEach(drop => {
  drop.addEventListener('touchstart', () => {
    drop.querySelector('.dropdown-content').classList.toggle('show');
  });
});